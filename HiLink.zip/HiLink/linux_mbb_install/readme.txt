--How to Install----------------------

1.   keep your right is "root"
2.   Run "./install" in TERMINAL to install 
3.   if you have installed before , intend to the istalling information
