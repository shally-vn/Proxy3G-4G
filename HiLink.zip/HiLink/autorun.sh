#!/bin/bash


CURRENT_PATH=`echo $0|sed 's/autorun.sh//'`

"${CURRENT_PATH}"/install_linux



