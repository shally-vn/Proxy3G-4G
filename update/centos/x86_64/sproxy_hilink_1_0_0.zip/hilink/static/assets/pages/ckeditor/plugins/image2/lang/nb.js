/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'nb', {
	alt: 'Alternativ tekst',
	btnUpload: 'Send det til serveren',
	captioned: 'Bilde med bildetekst',
	captionPlaceholder: 'Bildetekst',
	infoTab: 'Bildeinformasjon',
	lockRatio: 'Lås forhold',
	menu: 'Bildeegenskaper',
	pathName: 'bilde',
	pathNameCaption: 'bildetekst',
	resetSize: 'Tilbakestill størrelse',
	resizer: 'Klikk og dra for å endre størrelse',
	title: 'Bildeegenskaper',
	uploadTab: 'Last opp',
	urlMissing: 'Bildets adresse mangler.',
	altMissing: 'Alternativ tekst mangler.'
} );
